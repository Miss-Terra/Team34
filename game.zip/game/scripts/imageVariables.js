//Load our big list of image variables.

//--------------------Image Variables--------------------

	//Define background image variable.
	//When loaded, bgReady becomes true.
	var bgImage = new Image();
	var bgReady = false;
	bgImage.onload = function () {
		//background is safe to load...
		bgReady = true;
	};

	var dude = new Image();
	var personReady = false;
	dude.onload = function () {
		//Stickman is safe to load...
		personReady = true;
	};		

	var menuLogo = new Image();
	var mlogoReady = false;
	menuLogo.onload = function () {
		//logo is safe to load...
		mlogoReady = true;
	};		

	var scoreLogo = new Image();
	var slogoReady = false;
	scoreLogo.onload = function () {
		//logo is safe to load...
		slogoReady = true;
	};		
	
	var menuAnimationImage = new Image();
	var menuAnimationReady = false;
	menuAnimationImage.onload = function () {
		//Stickman is safe to load...
		menuAnimationReady = true;
	};	

	var borderImage = new Image();
	var borderReady = false;
	borderImage.onload = function () {
		//Stickman is safe to load...
		borderReady = true;
	};	

	var borderImage2 = new Image();
	var borderReady2 = false;
	borderImage2.onload = function () {
		//Stickman is safe to load...
		borderReady2 = true;
	};	
	
	var scrollImage = new Image();
	var scrollReady = false;
	scrollImage.onload = function () {
		//Stickman is safe to load...
		scrollReady = true;
	};


//----------------Buttons Image----------------

	var generateButtonImage = new Image();
	var buttonReady = false;
	generateButtonImage.onload = function () {
		//button image is safe to load...
		buttonReady = true;
	};
	
	var victoryButtonImage = new Image();
	var buttonReady = false;
	victoryButtonImage.onload = function () {
		//button image is safe to load...
		buttonReady = true;
	};
	
	var addscoreButtonImage = new Image();
	var buttonReady = false;
	addscoreButtonImage.onload = function () {
		//button image is safe to load...
		buttonReady = true;
	};
	
	var addGameOverButtonImage = new Image();
	var buttonReady = false;
	addGameOverButtonImage.onload = function () {
		//button image is safe to load...
		buttonReady = true;
	};


	// for music
	var speakerOnButtonImage = new Image();
	var buttonReady = false;
	speakerOnButtonImage.onload = function () {
		//button image is safe to load...
		buttonReady = true;
	};
	
	var speakerOffButtonImage = new Image();
	var buttonReady = false;
	speakerOffButtonImage.onload = function () {
		//button image is safe to load...
		buttonReady = true;
	};

	
	// for tutorial screen
	var backButtonImage = new Image();
	var backButtonReady = false;
	backButtonImage.onload = function () {
		//button image is safe to load...
		backButtonReady = true;
	};
	
	var nextButtonImage = new Image();
	var nextButtonReady = false;
	nextButtonImage.onload = function () {
		//button image is safe to load...
		nextButtonReady = true;
	};
	
	
	var achievementsButtonImage = new Image();
	var achievementsButtonReady = false;
	achievementsButtonImage.onload = function () {
		//button image is safe to load...
		achievementsButtonReady = true;
	};







	// Basic button
	var buttonImage = new Image();
	var buttonReady = false;
	buttonImage.onload = function () {
		//button image is safe to load...
		buttonReady = true;
	};

	var pauseButtonImage = new Image();
	var pauseButtonReady = false;
	pauseButtonImage.onload = function () {
		//button image is safe to load...
		buttonReady = true;
	};
	
	pauseButtonImage2 = new Image();
	pauseButtonReady2 = false;
	pauseButtonImage.onload = function () {
		//button image is safe to load...
		pauseButtonReady2 = true;
	};

	var mainMenuButtonImage = new Image();
	var mainMenuButtonReady = false;
	mainMenuButtonImage.onload = function () {
		//button image is safe to load...
		mainMenuButtonReady = true;
	};
	
	var playButtonImage = new Image();
	var playButtonReady = false;
	playButtonImage.onload = function () {
		//button image is safe to load...
		playButtonReady = true;
	};
	
	var tutorialButtonImage = new Image();
	var tutorialButtonReady = false;
	tutorialButtonImage.onload = function () {
		//button image is safe to load...
		tutorialButtonReady = true;
	};
	
	var scoreboardButtonImage = new Image();
	var scoreboardButtonReady = false;
	scoreboardButtonImage.onload = function () {
		//button image is safe to load...
		scoreboardButtonReady = true;
	};
	
	var creditsButtonImage = new Image();
	var creditsButtonReady = false;
	creditsButtonImage.onload = function () {
		//button image is safe to load...
		creditsButtonReady = true;
	};

	var restartButtonImage = new Image();
	var restartButtonReady = false;
	restartButtonImage.onload = function () {
		//button image is safe to load...
		restartButtonReady = true;
	};
	var resumeButtonImage = new Image();
	var resumeButtonReady = false;
	resumeButtonImage.onload = function () {
		//button image is safe to load...
		resumeButtonReady = true;
	};
